import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>Welcome to gptTok 🧠💙</h1>
      <p>Your emotional AI companion - AI Jan</p>
    </div>
  );
}

export default App;
