# gptTok 🤖✨

A beautiful, emotion-aware AI companion named **AI Jan**, built by Jubair al Mahmud 💖.

## 🧠 Features
- Chat with AI Jan
- Emotion memory
- Installable PWA
- Light/Dark mode support

## 🚀 Tech Stack
- React
- JavaScript
- HTML/CSS

## 📦 Setup
```bash
npm install
npm run build
```

Then deploy to Vercel 💫.
